<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
        <label for="">Nhập vào số a</label>
        <input type="text" name="so1"><br>
        <label for="">Nhập vào số b</label>
        <input type="text" name="so2"><br>
        <input type="submit" name="tinh" value="Tính">
    </form>
    
    <?php
    if(isset($_POST['tinh'])){
        $so1 = $_POST['so1'];
        $so2 = $_POST['so2'];
        echo dang3($so1, $so2);
    }

    function dang3($so1, $so2){
        $tb = ''; // Khai báo biến $tb trước khi sử dụng
        $tb .= 'Tổng của hai số: ' . ($so1 + $so2) . '<br>';
        $tb .= 'Hiệu của hai số: ' . ($so1 - $so2) . '<br>';
        $tb .= 'Tích của hai số: ' . ($so1 * $so2) . '<br>';
        if($so2 != 0){ // Kiểm tra điều kiện để tránh chia cho 0
            $thuong = $so1 / $so2;
            $tb .= 'Thương của hai số: ' . $thuong;
        } else {
            $tb .= 'Không thể chia cho 0';
        }
        return $tb; // Trả về giá trị của biến $tb
    }
    ?>
</body>
</html>
