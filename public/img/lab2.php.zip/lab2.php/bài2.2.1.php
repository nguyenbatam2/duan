<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="php echo $_SEVER['PHP_SELF']" method="post">
        <label for=""> nhap vao so a</label>
        <input type="text" name="so1"><br>
        <label for="" > nhap vao so b</label>
        <input type="text" name="so2"><br>
        <input type="submit" name="tinh">
    </form>
    
    <?php
    dang1(); //loiwf goij ham ten dang 1
    function dang1(){
        if(isset($_POST['tinh']) && $_POST['tinh']){
            $so1=$_POST['so1'];
            $so2=$_POST['so2'];
            echo'tong cua hai so'.($so1+$so2).'<br>';
            echo'hieu cua hai so'.($so1-$so2).'<br>';
            echo'tich cua hai so'.($so1*$so2).'<br>';
            $thuong=$so1/$so2;
            echo'thuong cua 2 so'.$thuong;
        }
    }
    ?>
</body>
</html>