<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="<?php echo $_SERVER['PHP_SELF']?>" method="post">
        <label for=""> nhap vao so a</label>
        <input type="text" name="so1"><br>
        <label for="" > nhap vao so b</label>
        <input type="text" name="so2"><br>
        <input type="submit" name="tinh">
    </form>
    
    <?php
     if(isset($_POST['tinh']) && $_POST['tinh']){
        $so1=$_POST['so1'];
        $so2=$_POST['so2'];
    echo dang3($so1,$so2);
}
    function dang3($so1,$so2){
            $tb ='';
            $tb.='tong cua hai so:'.($so1+$so2).'<br>';
            $tb.='hieu cua hai so:'.($so1-$so2).'<br>';
            $tb.='tich cua hai so:'.($so1*$so2).'<br>';
            
            if($so2!=0){
                $thuong=$so1/$so2;
                $tb.='thuong cu 2 so:'.$thuong;
            }else{
                $tb='thuong khong the chia cho 0';

            }
           return $tb;
        }

        
        
    
    ?>
</body>
</html>