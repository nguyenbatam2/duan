<form action="<?php echo $_SEVER['PHP_SELF']?>" method="post">
        <label for=""> nhap vao so </label>
        <input type="text" name="so"><br>
        <input type="submit" name="tinh">
    </form>
<?
// function chanle($so){
//     return;
// }
if(isset($_POST['tinh']) && $_POST['tinh']){
    $so1=$_POST['so'];
 $abc=taomang($so1);
 echo xuatmang($abc);

}
function taomang($spt){
    $mang=[];
    for($i=0;$i<$spt;$i++){
        $mang[]=rand(10,80);
    }
    return $mang;
}
function xuatmang($m){
    $chuoi='';
    foreach($m as $a){
        $chuoi.=$a.'br';
    }
    return $chuoi ;
}
?>