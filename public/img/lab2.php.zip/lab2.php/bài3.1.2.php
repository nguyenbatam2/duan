<form action="<?php echo $_SERVER['PHP_SELF']?>" method="post">
    <label for="so">Nhập vào số phần tử:</label>
    <input type="text" id="so" name="so"><br>
    <input type="submit" name="tinh" value="Tính">
</form>

<?php
if(isset($_POST['tinh'])){
    $so1 = isset($_POST['so']) ? (int)$_POST['so'] : 0; // Ép kiểu sang số nguyên
    $abc = taomang($so1);
    echo xuatmang($abc);
}

function taomang($spt){
    $mang = [];
    for($i = 0; $i < $spt; $i++){
        $mang[] = rand(10, 80);
    }
    return $mang;
}

function xuatmang($m){
    $chuoi = '';
    foreach($m as $a){
        $chuoi .= $a . '<br>'; // Thêm dấu <br> sau mỗi phần tử để xuống dòng
    }
    return $chuoi;
}
?>
